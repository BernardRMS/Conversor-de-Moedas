function Converter() {
  var valorElemento = document.getElementById("valor");
  var valor = valorElemento.value;
  var valorEmDolar = parseFloat(valor);
  var valorEmEuro = parseFloat(valor);
  var valorEmBitCoin = parseFloat(valor);

  var valorEmReal = valorEmDolar * 5;
  var valorEmReal2 = valorEmEuro * 6;
  var valorEmReal3 = valorEmBitCoin * 251;

  console.log(valorEmReal);
  console.log(valorEmReal2);

  var elementoValorConvertido = document.getElementById("valorConvertido");
  var elementoValorConvertido2 = document.getElementById("valorConvertido2");
  var elementoValorConvertido3 = document.getElementById("valorConvertido3");

  var valorConvertido = "O Dólar em Real é R$ " + valorEmReal;
  var valorConvertido2 = "O Euro em Real é R$ " + valorEmReal2;
  var valorConvertido3 = "O Bitcoin em Real é R$ " + valorEmReal3;

  elementoValorConvertido.innerHTML = valorConvertido;
  elementoValorConvertido2.innerHTML = valorConvertido2;
  elementoValorConvertido3.innerHTML = valorConvertido3;
}
